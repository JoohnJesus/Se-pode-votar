using System;

class Program {
  public static void Main (string[] args) {

 //desvios condicionais//

    Console.Write ("Qual sua idade? ");
    int idade = int.Parse(Console.ReadLine());

if (idade >= 70) {
  Console.WriteLine("Idade acima do solicitado. Voto opcional!");
}
    
    else if (idade >=16) {
      Console.WriteLine("Você pode votar!");
    }
    

    else {
      Console.WriteLine("Você não pode votar");
    }
    
  }
}