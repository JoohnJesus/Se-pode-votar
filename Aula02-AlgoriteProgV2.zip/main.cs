using System;

class Program {
  public static void Main (string[] args) {

 //desvios condicionais//

    Console.Write ("Qual sua idade? ");
    int idade = int.Parse(Console.ReadLine());


    // If alinhado
    

    
if (idade >= 70) {
  Console.WriteLine("Idade acima do solicitado. Voto opcional!");
}
    
    else if (idade >=16) {
      Console.WriteLine("Você pode votar!");
    }


    else if (idade <= 0) {
        Console.WriteLine("Essa idade não é permitida!");
      }
      
    else {
      Console.WriteLine("Muito jovem, idade não permitida!");
    }


      
  }
}